import { Link, useLocation } from "wouter";
import { Gamepad2, ShoppingBag, Link2, Bot, Wrench, LogIn, Sun, Moon, Globe, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/use-auth";
import { useLanguage } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";

const navItems = [
  { href: "/products", labelKey: "nav.products", icon: ShoppingBag },
  { href: "/bio", labelKey: "nav.bio", icon: Link2 },
  { href: "/topup", labelKey: "nav.topup", icon: Gamepad2 },
  { href: "/bot", labelKey: "nav.bot", icon: Bot },
  { href: "/tools", labelKey: "nav.tools", icon: Wrench },
  { href: "/websites", labelKey: "nav.websites", icon: Code },
];

export function Navigation() {
  const [location] = useLocation();
  const { user, isLoading, isAuthenticated } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const { theme, toggleTheme } = useTheme();

  const initials = user ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U' : '';

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-primary/20 bg-background/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2">
        <Link href="/" className="flex items-center gap-2 group shrink-0">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center text-primary group-hover:animate-glow transition-all">
            <Gamepad2 className="w-5 h-5" />
          </div>
          <span className="text-lg text-foreground hidden sm:block brand-heading">
            {language === "ar" ? "متجر" : "Saddam"} <span className="text-primary">{language === "ar" ? "صدام" : "Store"}</span>
          </span>
        </Link>

        <div className="flex items-center gap-1 overflow-x-auto">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className={`text-xs sm:text-sm whitespace-nowrap ${isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
                  data-testid={`nav-${item.labelKey.split('.')[1]}`}
                >
                  <Icon className="w-4 h-4 sm:me-1" />
                  <span className="hidden sm:inline">{t(item.labelKey)}</span>
                </Button>
              </Link>
            );
          })}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <Button
            size="icon"
            variant="ghost"
            onClick={toggleTheme}
            className="text-muted-foreground"
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
            className="text-muted-foreground"
            data-testid="button-language-toggle"
          >
            <span className="text-xs font-bold">{language === "ar" ? "EN" : "ع"}</span>
          </Button>

          {isLoading ? (
            <div className="w-8 h-8 rounded-full bg-primary/20 animate-pulse" />
          ) : isAuthenticated && user ? (
            <Link href="/profile">
              <Avatar className="w-8 h-8 cursor-pointer ring-2 ring-primary/30 hover:ring-primary/60 transition-all" data-testid="avatar-profile">
                <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || 'User'} />
                <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </Link>
          ) : (
            <Button
              size="sm"
              className="bg-primary text-primary-foreground"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-login"
            >
              <LogIn className="w-4 h-4 sm:me-1" />
              <span className="hidden sm:inline">{t("nav.login")}</span>
            </Button>
          )}
        </div>
      </div>
    </nav>
  );
}
