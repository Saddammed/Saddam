import { Link } from "wouter";
import { ArrowRight, DollarSign } from "lucide-react";

interface ProjectCardProps {
  title: string;
  description: string;
  href: string;
  icon: React.ReactNode;
  color: string;
  earning?: string;
}

export function ProjectCard({ title, description, href, icon, color, earning }: ProjectCardProps) {
  return (
    <Link href={href} className="block group">
      <div className={`
        relative overflow-hidden rounded-3xl p-6 h-full border border-white/5
        bg-gradient-to-br from-white/5 to-white/0 backdrop-blur-sm
        hover:border-${color}/50 hover:shadow-2xl hover:shadow-${color}/20
        transition-all duration-300 transform hover:-translate-y-1
      `}>
        <div className={`
          absolute top-0 right-0 w-32 h-32 bg-${color}/20 rounded-full blur-3xl 
          -translate-y-1/2 translate-x-1/2 group-hover:bg-${color}/30 transition-all
        `} />
        
        <div className="relative z-10">
          <div className={`
            w-12 h-12 rounded-xl flex items-center justify-center mb-4
            bg-${color}/10 text-${color} border border-${color}/20
            group-hover:scale-110 transition-transform duration-300
          `}>
            {icon}
          </div>
          
          <h3 className="text-xl font-display font-bold text-white mb-2">{title}</h3>
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">{description}</p>
          
          {earning && (
            <div className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-full w-fit mb-4">
              <DollarSign className="w-3 h-3" />
              {earning}
            </div>
          )}
          
          <div className={`
            flex items-center text-sm font-semibold text-${color}
            group-hover:translate-x-1 transition-transform
          `}>
            View Demo <ArrowRight className="w-4 h-4 ml-1" />
          </div>
        </div>
      </div>
    </Link>
  );
}
