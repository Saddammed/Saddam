import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useBioLinks() {
  return useQuery({
    queryKey: [api.bioLinks.list.path],
    queryFn: async () => {
      const res = await fetch(api.bioLinks.list.path);
      if (!res.ok) throw new Error("Failed to fetch bio links");
      return api.bioLinks.list.responses[200].parse(await res.json());
    },
  });
}
