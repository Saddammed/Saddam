import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertTopupRequest } from "@shared/routes";

export function useTopups() {
  return useQuery({
    queryKey: [api.topups.list.path],
    queryFn: async () => {
      const res = await fetch(api.topups.list.path);
      if (!res.ok) throw new Error("Failed to fetch topups");
      return api.topups.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateTopup() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertTopupRequest) => {
      const validated = api.topups.create.input.parse(data);
      const res = await fetch(api.topups.create.path, {
        method: api.topups.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.topups.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create topup request");
      }
      return api.topups.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.topups.list.path] }),
  });
}
