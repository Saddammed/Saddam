import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useBotLogs() {
  return useQuery({
    queryKey: [api.bot.logs.path],
    queryFn: async () => {
      const res = await fetch(api.bot.logs.path);
      if (!res.ok) throw new Error("Failed to fetch bot logs");
      return api.bot.logs.responses[200].parse(await res.json());
    },
    refetchInterval: 3000, // Poll every 3s for live logs
  });
}

export function useBotStatus() {
  return useQuery({
    queryKey: [api.bot.status.path],
    queryFn: async () => {
      const res = await fetch(api.bot.status.path);
      if (!res.ok) throw new Error("Failed to fetch bot status");
      return api.bot.status.responses[200].parse(await res.json());
    },
  });
}
