import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useGenerateSaas() {
  return useMutation({
    mutationFn: async (keyword: string) => {
      const res = await fetch(api.saas.generate.path, {
        method: api.saas.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyword }),
      });
      if (!res.ok) throw new Error("Failed to generate");
      return api.saas.generate.responses[201].parse(await res.json());
    },
  });
}
