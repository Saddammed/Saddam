import { useCreateTopup, useTopups } from "@/hooks/use-topups";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTopupRequestSchema, type InsertTopupRequest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Gamepad2, Diamond, History, Clock, CheckCircle, Shield, Zap, CreditCard, MessageCircle } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { motion } from "framer-motion";

export default function TopupDemo() {
  const { toast } = useToast();
  const createTopup = useCreateTopup();
  const { data: recentTopups } = useTopups();

  const form = useForm<InsertTopupRequest>({
    resolver: zodResolver(insertTopupRequestSchema),
    defaultValues: {
      playerId: "",
      amount: "100",
    },
  });

  function onSubmit(data: InsertTopupRequest) {
    createTopup.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Order Submitted!",
          description: "Your top-up request is being processed. We'll notify you when complete.",
        });
        form.reset();
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  }

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 bg-slate-900 text-white font-sans">
      <div className="max-w-5xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-white mb-3">Game Currency Top-up</h1>
          <p className="text-slate-400 max-w-xl mx-auto">
            Instant delivery of in-game currency. Fast, secure, and trusted by thousands of gamers.
          </p>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-3 gap-4 mb-10">
          <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <div className="font-bold text-white">Instant</div>
            <div className="text-xs text-slate-400">5-minute delivery</div>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="font-bold text-white">Secure</div>
            <div className="text-xs text-slate-400">100% safe</div>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-xl border border-slate-700">
            <CreditCard className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="font-bold text-white">Easy Pay</div>
            <div className="text-xs text-slate-400">Multiple options</div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          
          {/* Left: Form */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-slate-800 rounded-3xl p-8 border border-slate-700 shadow-2xl"
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center text-emerald-500">
                <Gamepad2 className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Top-up Now</h2>
                <p className="text-slate-400 text-sm">Instant delivery 24/7</p>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="playerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Player ID / Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your game ID" 
                          {...field} 
                          className="bg-slate-900 border-slate-700 h-12 rounded-xl focus:ring-emerald-500"
                          data-testid="input-player-id"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Select Package</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-slate-900 border-slate-700 h-12 rounded-xl" data-testid="select-amount">
                            <SelectValue placeholder="Select amount" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="100">
                            <div className="flex items-center gap-2">
                              <Diamond className="w-4 h-4 text-blue-400" /> 100 Gems - $0.99
                            </div>
                          </SelectItem>
                          <SelectItem value="500">
                            <div className="flex items-center gap-2">
                              <Diamond className="w-4 h-4 text-blue-400" /> 500 Gems - $4.99
                            </div>
                          </SelectItem>
                          <SelectItem value="1000">
                            <div className="flex items-center gap-2">
                              <Diamond className="w-4 h-4 text-purple-400" /> 1000 Gems - $9.99
                            </div>
                          </SelectItem>
                          <SelectItem value="2500">
                            <div className="flex items-center gap-2">
                              <Diamond className="w-4 h-4 text-yellow-400" /> 2500 Gems - $19.99
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full h-12 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-lg shadow-lg shadow-emerald-500/20"
                  disabled={createTopup.isPending}
                  data-testid="button-submit-topup"
                >
                  {createTopup.isPending ? "Processing..." : "Purchase Now"}
                </Button>

                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-slate-700" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-slate-800 px-2 text-slate-500">Or</span>
                  </div>
                </div>

                <Button 
                  type="button"
                  variant="outline"
                  className="w-full h-12 rounded-xl border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white font-bold"
                  data-testid="button-whatsapp-order"
                  onClick={() => {
                    const msg = `Hi! I want to order ${form.getValues().amount} Gems for Player ID: ${form.getValues().playerId}`;
                    window.open(`https://wa.me/1234567890?text=${encodeURIComponent(msg)}`, '_blank');
                  }}
                >
                  <SiWhatsapp className="w-5 h-5 mr-2" />
                  Order via WhatsApp
                </Button>
              </form>
            </Form>
          </motion.div>

          {/* Right: Recent Activity */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-2 text-slate-400 mb-4">
              <History className="w-5 h-5" />
              <span className="font-medium">Recent Transactions</span>
            </div>

            <div className="space-y-3">
              {!recentTopups || recentTopups.length === 0 ? (
                [1, 2, 3].map((i) => (
                  <div key={i} className="bg-slate-800/50 rounded-xl p-4 flex items-center justify-between border border-slate-800">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
                        <Diamond className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <div className="font-bold text-sm">500 Gems</div>
                        <div className="text-xs text-slate-500">ID: Player{88392 + i}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
                      <CheckCircle className="w-3 h-3" /> Complete
                    </div>
                  </div>
                ))
              ) : (
                recentTopups.map((t) => (
                  <div key={t.id} className="bg-slate-800/50 rounded-xl p-4 flex items-center justify-between border border-slate-800">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
                        <Diamond className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <div className="font-bold text-sm">{t.amount} Gems</div>
                        <div className="text-xs text-slate-500">ID: {t.playerId || 'N/A'}</div>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${t.status === 'completed' ? 'text-green-400 bg-green-400/10' : 'text-yellow-400 bg-yellow-400/10'}`}>
                      {t.status === 'completed' ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />} 
                      {t.status}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Support Section */}
            <div className="mt-8 p-4 bg-slate-800/30 rounded-xl border border-slate-700">
              <p className="text-slate-400 text-sm mb-3">Need help with your order?</p>
              <Button 
                variant="outline" 
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                data-testid="button-support"
                onClick={() => window.open('https://wa.me/1234567890?text=I need help with my order', '_blank')}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
}
