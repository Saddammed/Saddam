import { useBotLogs, useBotStatus } from "@/hooks/use-bot";
import { Bot, Terminal, Activity, Radio, Send, MessageCircle, Zap, Users } from "lucide-react";
import { SiTelegram } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

export default function BotDemo() {
  const { data: logs } = useBotLogs();
  const { data: status } = useBotStatus();

  const isOnline = status?.status === 'running';
  const uptime = status?.uptime ? Math.floor(status.uptime / 60) : 0;

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8 bg-slate-950">
      <div className="max-w-5xl mx-auto">
        
        {/* Marketing Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-3">Telegram Bot Template</h1>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Automate your business with a custom Telegram bot. Handle customer inquiries, 
            send product links, and grow your audience 24/7.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
            <Zap className="w-8 h-8 text-yellow-400 mb-2" />
            <h3 className="font-bold text-white">Instant Replies</h3>
            <p className="text-sm text-slate-400">Respond to customers automatically 24/7</p>
          </div>
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
            <Users className="w-8 h-8 text-blue-400 mb-2" />
            <h3 className="font-bold text-white">Grow Subscribers</h3>
            <p className="text-sm text-slate-400">Build your community on autopilot</p>
          </div>
          <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
            <MessageCircle className="w-8 h-8 text-green-400 mb-2" />
            <h3 className="font-bold text-white">Send Product Links</h3>
            <p className="text-sm text-slate-400">Share your products instantly</p>
          </div>
        </div>
        
        {/* Header Status */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 mb-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${isOnline ? 'bg-sky-500/20 text-sky-500' : 'bg-red-500/20 text-red-500'}`}>
              <Bot className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white mb-1">Telegram Assistant</h1>
              <div className="flex items-center gap-2">
                <span className={`flex w-2 h-2 rounded-full ${isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                <span className="text-slate-400 font-mono text-sm uppercase">{status?.status || 'Active'}</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-8 text-center sm:text-right">
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">Uptime</div>
              <div className="text-xl font-mono text-white font-bold">{uptime}m</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">Messages</div>
              <div className="text-xl font-mono text-white font-bold">{logs?.length || 0}</div>
            </div>
          </div>
        </div>

        {/* Bot Commands Info */}
        <div className="bg-slate-900/50 rounded-xl border border-slate-800 p-6 mb-8">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Terminal className="w-5 h-5 text-slate-400" />
            Available Commands
          </h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="bg-slate-800/50 rounded-lg p-3">
              <code className="text-sky-400">/start</code>
              <p className="text-sm text-slate-400 mt-1">Welcome message with menu options</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-3">
              <code className="text-sky-400">/help</code>
              <p className="text-sm text-slate-400 mt-1">Show all available commands</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-3">
              <code className="text-sky-400">/products</code>
              <p className="text-sm text-slate-400 mt-1">Browse available products</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-3">
              <code className="text-sky-400">/contact</code>
              <p className="text-sm text-slate-400 mt-1">Get support contact info</p>
            </div>
          </div>
        </div>

        {/* Console View */}
        <div className="bg-black rounded-2xl border border-slate-800 overflow-hidden shadow-2xl font-mono">
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-slate-400" />
            <span className="text-sm text-slate-400">Live Logs</span>
            <span className="ml-auto flex items-center gap-1 text-xs text-green-400">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live
            </span>
          </div>
          
          <div className="p-4 h-[400px] overflow-y-auto space-y-2">
            {!logs || logs.length === 0 ? (
              <>
                <div className="flex gap-4 text-sm text-slate-500">
                  <span>{format(new Date(), 'HH:mm:ss')}</span>
                  <span className="text-green-500">[SYSTEM]</span>
                  <span>Bot initialized successfully v1.0.4</span>
                </div>
                <div className="flex gap-4 text-sm text-slate-500">
                  <span>{format(new Date(), 'HH:mm:ss')}</span>
                  <span className="text-blue-500">[INBOUND]</span>
                  <span>User @johndoe sent: /start</span>
                </div>
                <div className="flex gap-4 text-sm text-slate-500">
                  <span>{format(new Date(), 'HH:mm:ss')}</span>
                  <span className="text-purple-500">[OUTBOUND]</span>
                  <span>Welcome to our store! Use /products to browse our catalog.</span>
                </div>
              </>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="flex gap-4 text-sm text-slate-400 hover:bg-slate-900/50 p-1 rounded">
                  <span className="text-slate-600 w-20 shrink-0">{log.timestamp ? format(new Date(log.timestamp), 'HH:mm:ss') : '--:--'}</span>
                  <span className={`w-24 shrink-0 font-bold ${log.direction === 'inbound' ? 'text-blue-500' : 'text-purple-500'}`}>
                    [{log.direction.toUpperCase()}]
                  </span>
                  <span className="text-slate-300 break-all">{log.message}</span>
                </div>
              ))
            )}
            
            <div className="w-2 h-4 bg-slate-500 animate-pulse mt-2" />
          </div>
        </div>

        {/* CTA */}
        <div className="mt-8 text-center">
          <p className="text-slate-400 mb-4">Want your own Telegram bot for your business?</p>
          <Button 
            size="lg"
            className="bg-[#0088cc] hover:bg-[#006699] text-white h-12 px-8 rounded-full"
            data-testid="button-telegram-cta"
            onClick={() => window.open('https://t.me/yourusername', '_blank')}
          >
            <SiTelegram className="w-5 h-5 mr-2" />
            Contact Us on Telegram
          </Button>
        </div>

      </div>
    </div>
  );
}
