import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bot, MessageCircle, Send, ShoppingBag, Gamepad2, Link2, CheckCircle, Copy } from "lucide-react";
import { SiTelegram, SiWhatsapp, SiTiktok } from "react-icons/si";
import { useState } from "react";
import { motion } from "framer-motion";

const WHATSAPP_LINK = "https://wa.me/message/REDKIHRAVCUEB1";
const TIKTOK_LINK = "https://www.tiktok.com/@saddamhub";

const commands = [
  { 
    cmd: "/start", 
    desc: "Welcome message with menu options",
    response: `مرحباً بك في متجر صدام! 🎮

⚡ للاستفادة من خدماتنا، يرجى الاشتراك أولاً:

1️⃣ قناة تليجرام (إجباري ✅)
2️⃣ قناة واتساب (إجباري ✅)
3️⃣ تيك توك (إجباري ✅)
4️⃣ فيسبوك (إجباري ✅)`
  },
  { cmd: "/products", desc: "View our digital products" },
  { cmd: "/topup", desc: "Order game currency topups" },
  { cmd: "/links", desc: "Get all our social links" },
  { cmd: "/help", desc: "Show available commands" }
];

const features = [
  { icon: MessageCircle, title: "Auto-Reply", desc: "Instant responses 24/7" },
  { icon: ShoppingBag, title: "Product Catalog", desc: "Browse products in-chat" },
  { icon: Gamepad2, title: "Quick Topups", desc: "Order directly via bot" },
  { icon: Link2, title: "Link Sharing", desc: "Easy access to all links" }
];

export default function BotPage() {
  const [copied, setCopied] = useState(false);

  const copyBotLink = () => {
    navigator.clipboard.writeText("https://t.me/StorSaddam_bot");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-5xl mx-auto">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-blue-500/20 text-blue-400 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Bot className="w-4 h-4" />
            Telegram Bot
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">بوت متجر صدام</h1>
          <p className="text-muted-foreground max-w-lg mx-auto mb-6">
            تفاعل مع البوت للوصول السريع للمنتجات والشحن والدعم.
          </p>
          <Button 
            size="lg"
            className="bg-[#0088cc] hover:bg-[#006699] text-white h-14 px-10 rounded-full text-lg"
            data-testid="button-start-now"
            onClick={() => window.open('https://t.me/StorSaddam_bot?start=welcome', '_blank')}
          >
            <SiTelegram className="w-6 h-6 mr-3" />
            ابدأ الآن
          </Button>
        </motion.div>

        {/* Bot Preview */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-12"
        >
          <Card className="bg-card border-border overflow-hidden">
            <CardHeader className="bg-[#0088cc] text-white">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <SiTelegram className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-white">بوت متجر صدام</CardTitle>
                  <p className="text-white/70 text-sm">@StorSaddam_bot</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {/* Chat Preview */}
              <div className="bg-[#0e1621] p-4 space-y-4 min-h-[300px]">
                {/* User message */}
                <div className="flex justify-end">
                  <div className="bg-[#2b5278] text-white px-4 py-2 rounded-2xl rounded-tr-sm max-w-xs">
                    /start
                  </div>
                </div>
                {/* Bot response */}
                <div className="flex justify-start">
                  <div className="bg-[#182533] text-white px-4 py-3 rounded-2xl rounded-tl-sm max-w-sm">
                    <p className="whitespace-pre-line mb-4">{commands[0].response}</p>
                    <div className="space-y-2">
                      <button className="w-full text-left px-3 py-2 bg-[#2b5278] rounded-lg hover:bg-[#3a6a9e] transition-colors text-sm">
                        <SiWhatsapp className="w-4 h-4 inline mr-2" /> WhatsApp Orders
                      </button>
                      <button className="w-full text-left px-3 py-2 bg-[#2b5278] rounded-lg hover:bg-[#3a6a9e] transition-colors text-sm">
                        <Gamepad2 className="w-4 h-4 inline mr-2" /> Game Topup
                      </button>
                      <button className="w-full text-left px-3 py-2 bg-[#2b5278] rounded-lg hover:bg-[#3a6a9e] transition-colors text-sm">
                        <ShoppingBag className="w-4 h-4 inline mr-2" /> Products
                      </button>
                      <button className="w-full text-left px-3 py-2 bg-[#2b5278] rounded-lg hover:bg-[#3a6a9e] transition-colors text-sm">
                        <SiTiktok className="w-4 h-4 inline mr-2" /> TikTok
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          
          {/* Commands */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <Send className="w-5 h-5 text-blue-400" />
                  Bot Commands
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {commands.map(c => (
                  <div key={c.cmd} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                    <code className="text-blue-400 font-mono text-sm shrink-0">{c.cmd}</code>
                    <span className="text-muted-foreground text-sm">{c.desc}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>

          {/* Features */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-foreground flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  Bot Features
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {features.map(f => {
                  const Icon = f.icon;
                  return (
                    <div key={f.title} className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{f.title}</div>
                        <div className="text-sm text-muted-foreground">{f.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </motion.div>

        </div>

        {/* CTA */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-12 text-center p-8 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-2xl border border-blue-500/20"
        >
          <SiTelegram className="w-12 h-12 text-blue-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Try Our Bot Now</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Start chatting with our bot on Telegram for instant access to products and services!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg"
              className="bg-[#0088cc] hover:bg-[#006699] text-white h-12 px-8 rounded-full"
              data-testid="button-open-telegram"
              onClick={() => window.open('https://t.me/StorSaddam_bot', '_blank')}
            >
              <SiTelegram className="w-5 h-5 mr-2" />
              Open in Telegram
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10 h-12 px-8 rounded-full"
              data-testid="button-copy-link"
              onClick={copyBotLink}
            >
              {copied ? <CheckCircle className="w-5 h-5 mr-2" /> : <Copy className="w-5 h-5 mr-2" />}
              {copied ? "Copied!" : "Copy Link"}
            </Button>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
