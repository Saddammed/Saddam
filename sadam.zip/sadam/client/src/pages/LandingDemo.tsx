import { useProducts } from "@/hooks/use-products";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Star, Check, MessageCircle, CreditCard, Shield, Truck } from "lucide-react";
import { SiPaypal, SiWhatsapp } from "react-icons/si";
import { motion } from "framer-motion";

export default function LandingDemo() {
  const { data: products, isLoading } = useProducts();
  const product = products?.[0];

  if (isLoading) return <div className="min-h-screen pt-20 flex items-center justify-center text-white">Loading...</div>;

  const displayProduct = product || {
    name: "Premium Wireless Headphones",
    description: "Experience crystal clear sound with our latest noise-cancelling technology. Perfect for travel, work, and relaxation.",
    price: "$299.00",
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80"
  };

  const whatsappLink = `https://wa.me/1234567890?text=Hi! I'm interested in buying ${encodeURIComponent(displayProduct.name)}`;

  return (
    <div className="min-h-screen pt-16 bg-white text-slate-900 font-sans">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="order-2 lg:order-1 space-y-8"
          >
            <div className="flex items-center gap-2 text-yellow-500 font-medium">
              <Star className="w-5 h-5 fill-current" />
              <Star className="w-5 h-5 fill-current" />
              <Star className="w-5 h-5 fill-current" />
              <Star className="w-5 h-5 fill-current" />
              <Star className="w-5 h-5 fill-current" />
              <span className="text-slate-600 ml-2">4.9/5 (2,847 reviews)</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-display font-bold tracking-tight text-slate-900 leading-tight">
              {displayProduct.name}
            </h1>
            
            <p className="text-xl text-slate-600 leading-relaxed">
              {displayProduct.description}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500">
              <div className="flex items-center gap-1"><Truck className="w-4 h-4 text-green-500" /> Free Shipping</div>
              <div className="flex items-center gap-1"><Shield className="w-4 h-4 text-green-500" /> 2 Year Warranty</div>
              <div className="flex items-center gap-1"><Check className="w-4 h-4 text-green-500" /> 30-Day Returns</div>
            </div>

            <div className="text-4xl font-bold text-slate-900">
              {displayProduct.price}
              <span className="text-lg text-slate-400 line-through ml-3">$399.00</span>
              <span className="text-sm bg-red-100 text-red-600 px-2 py-1 rounded-full ml-3">25% OFF</span>
            </div>

            {/* Payment Buttons */}
            <div className="flex flex-col gap-4 pt-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <Button 
                  size="lg"
                  className="text-lg px-8 h-14 rounded-full bg-[#0070ba] hover:bg-[#005ea6] text-white shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 flex items-center gap-2"
                  data-testid="button-paypal"
                  onClick={() => window.open('https://paypal.me/yourname', '_blank')}
                >
                  <SiPaypal className="w-5 h-5" />
                  Pay with PayPal
                </Button>
                <Button 
                  size="lg"
                  className="text-lg px-8 h-14 rounded-full bg-[#25D366] hover:bg-[#128C7E] text-white shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 flex items-center gap-2"
                  data-testid="button-whatsapp"
                  onClick={() => window.open(whatsappLink, '_blank')}
                >
                  <SiWhatsapp className="w-5 h-5" />
                  Order via WhatsApp
                </Button>
              </div>
              <Button 
                variant="outline" 
                size="lg"
                className="text-lg px-8 h-14 rounded-full border-2 border-slate-200 hover:bg-slate-50 text-slate-900"
                data-testid="button-learn-more"
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Other Payment Options
              </Button>
            </div>

            <p className="text-xs text-slate-400 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Secure checkout. Your payment information is protected.
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="order-1 lg:order-2 relative"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-100 to-purple-100 rounded-full blur-3xl opacity-60 -z-10" />
            <img 
              src={displayProduct.imageUrl} 
              alt={displayProduct.name}
              className="w-full h-auto rounded-3xl shadow-2xl hover:scale-105 transition-transform duration-500 animate-float"
              data-testid="img-product"
            />
          </motion.div>
        </div>
      </div>

      {/* Trust Badges */}
      <div className="bg-slate-50 py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-slate-900">50K+</div>
              <div className="text-slate-500">Happy Customers</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-slate-900">4.9/5</div>
              <div className="text-slate-500">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-slate-900">24/7</div>
              <div className="text-slate-500">Customer Support</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-slate-900">100%</div>
              <div className="text-slate-500">Satisfaction</div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Limited Time Offer - 25% Off!
          </h2>
          <p className="text-slate-300 text-lg mb-8">
            Don't miss out on this exclusive deal. Order now and get free express shipping!
          </p>
          <Button 
            size="lg"
            className="text-lg px-10 h-14 rounded-full bg-white text-slate-900 hover:bg-slate-100 shadow-xl"
            data-testid="button-cta-order"
            onClick={() => window.open(whatsappLink, '_blank')}
          >
            <ShoppingCart className="w-5 h-5 mr-2" />
            Order Now
          </Button>
        </div>
      </div>
    </div>
  );
}
