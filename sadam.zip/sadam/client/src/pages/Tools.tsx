import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Hash, User, FileText, MessageSquare, ShoppingBag, Mail, Sparkles, Copy, Check, Rocket } from "lucide-react";
import { motion } from "framer-motion";

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Button size="icon" variant="ghost" onClick={copy} className="shrink-0" data-testid="button-copy">
      {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
    </Button>
  );
}

function HashtagGenerator() {
  const [keyword, setKeyword] = useState("");
  const [result, setResult] = useState("");

  const generate = () => {
    if (!keyword.trim()) return;
    const base = keyword.toLowerCase().replace(/\s+/g, '');
    const hashtags = [
      `#${base}`, `#${base}viral`, `#${base}fyp`, `#${base}trending`,
      `#${base}life`, `#${base}daily`, `#${base}lover`, `#${base}vibes`,
      `#${base}community`, `#${base}tips`, `#${base}motivation`, `#${base}goals`,
      `#love${base}`, `#my${base}`, `#best${base}`, `#${base}2024`,
      `#${base}reels`, `#${base}shorts`, `#viral${base}`, `#trending${base}`
    ];
    setResult(hashtags.join(' '));
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter keyword (e.g. gaming, fitness)"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-hashtag"
        />
        <Button onClick={generate} data-testid="button-generate-hashtag">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {result && (
        <div className="p-4 bg-muted rounded-lg flex items-start gap-2">
          <p className="text-foreground text-sm break-words flex-1">{result}</p>
          <CopyButton text={result} />
        </div>
      )}
    </div>
  );
}

function CaptionGenerator() {
  const [topic, setTopic] = useState("");
  const [results, setResults] = useState<string[]>([]);

  const generate = () => {
    if (!topic.trim()) return;
    const t = topic.trim();
    const captions = [
      `POV: You finally discovered ${t} and your life changed forever`,
      `${t} hits different when you actually understand it`,
      `Nobody talks about ${t} like this... but here I am`,
      `Day 1 of making ${t} my entire personality`,
      `This ${t} hack saved me 10 hours (not clickbait)`
    ];
    setResults(captions);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter topic (e.g. productivity, cooking)"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-caption"
        />
        <Button onClick={generate} data-testid="button-generate-caption">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {results.length > 0 && (
        <div className="space-y-2">
          {results.map((caption, i) => (
            <div key={i} className="p-3 bg-muted rounded-lg flex items-center gap-2">
              <p className="text-foreground text-sm flex-1">{caption}</p>
              <CopyButton text={caption} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function BioGenerator() {
  const [niche, setNiche] = useState("");
  const [results, setResults] = useState<string[]>([]);

  const generate = () => {
    if (!niche.trim()) return;
    const n = niche.trim();
    const bios = [
      `${n} creator | Building in public | DM for collabs`,
      `Obsessed with ${n} | Sharing what I learn daily`,
      `Your go-to source for ${n} tips | Link below`
    ];
    setResults(bios);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter your niche (e.g. tech, fashion)"
          value={niche}
          onChange={(e) => setNiche(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-bio"
        />
        <Button onClick={generate} data-testid="button-generate-bio">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {results.length > 0 && (
        <div className="space-y-2">
          {results.map((bio, i) => (
            <div key={i} className="p-3 bg-muted rounded-lg flex items-center gap-2">
              <p className="text-foreground text-sm flex-1">{bio}</p>
              <CopyButton text={bio} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UsernameGenerator() {
  const [niche, setNiche] = useState("");
  const [results, setResults] = useState<string[]>([]);

  const generate = () => {
    if (!niche.trim()) return;
    const base = niche.toLowerCase().replace(/\s+/g, '');
    const prefixes = ['the', 'official', 'real', 'its', 'hey'];
    const suffixes = ['hub', 'zone', 'world', 'daily', 'hq'];
    const names = [
      ...prefixes.map(p => `@${p}${base}`),
      ...suffixes.map(s => `@${base}${s}`)
    ];
    setResults(names);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter niche (e.g. gaming, beauty)"
          value={niche}
          onChange={(e) => setNiche(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-username"
        />
        <Button onClick={generate} data-testid="button-generate-username">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {results.length > 0 && (
        <div className="grid grid-cols-2 gap-2">
          {results.map((name, i) => (
            <div key={i} className="p-3 bg-muted rounded-lg flex items-center gap-2">
              <span className="text-foreground text-sm font-mono flex-1">{name}</span>
              <CopyButton text={name} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProductDescGenerator() {
  const [product, setProduct] = useState("");
  const [result, setResult] = useState("");

  const generate = () => {
    if (!product.trim()) return;
    const p = product.trim();
    const desc = `Introducing ${p} - the ultimate solution you've been waiting for!

This premium ${p} is designed to transform your experience. With its cutting-edge features and unmatched quality, you'll wonder how you ever lived without it.

What you get:
- Premium quality that lasts
- Fast delivery guaranteed  
- 24/7 customer support
- 100% satisfaction or money back

Don't miss out - order your ${p} today and join thousands of happy customers!

Limited stock available. Order now before it's gone!`;
    setResult(desc);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter product name"
          value={product}
          onChange={(e) => setProduct(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-product"
        />
        <Button onClick={generate} data-testid="button-generate-product">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {result && (
        <div className="p-4 bg-muted rounded-lg">
          <div className="flex justify-end mb-2">
            <CopyButton text={result} />
          </div>
          <p className="text-foreground text-sm whitespace-pre-line">{result}</p>
        </div>
      )}
    </div>
  );
}

function DMScriptGenerator() {
  const [service, setService] = useState("");
  const [result, setResult] = useState("");

  const generate = () => {
    if (!service.trim()) return;
    const s = service.trim();
    const script = `Hey!

I noticed you might be interested in ${s}. I wanted to reach out personally because I think this could really help you.

Here's what I can offer:
- Professional ${s} service
- Quick turnaround time
- Competitive pricing
- Full support included

Would you like me to share more details? I'm happy to answer any questions you have.

Just reply "YES" and I'll send you everything you need to know!

Looking forward to hearing from you.`;
    setResult(script);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input 
          placeholder="Enter product/service name"
          value={service}
          onChange={(e) => setService(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && generate()}
          data-testid="input-dm"
        />
        <Button onClick={generate} data-testid="button-generate-dm">
          <Sparkles className="w-4 h-4 mr-2" />
          Generate
        </Button>
      </div>
      {result && (
        <div className="p-4 bg-muted rounded-lg">
          <div className="flex justify-end mb-2">
            <CopyButton text={result} />
          </div>
          <p className="text-foreground text-sm whitespace-pre-line">{result}</p>
        </div>
      )}
    </div>
  );
}

const tools = [
  {
    id: "hashtag",
    title: "Viral Hashtag Generator",
    titleAr: "مولد الهاشتاقات",
    description: "Generate 20 viral hashtags for TikTok, Reels & Shorts",
    icon: Hash,
    color: "text-pink-400",
    component: HashtagGenerator
  },
  {
    id: "caption",
    title: "Viral Caption Generator",
    titleAr: "مولد الكابشنات",
    description: "Generate 5 viral social media captions",
    icon: MessageSquare,
    color: "text-blue-400",
    component: CaptionGenerator
  },
  {
    id: "bio",
    title: "Bio Generator",
    titleAr: "مولد البايو",
    description: "Generate 3 ready-to-use TikTok bios",
    icon: FileText,
    color: "text-green-400",
    component: BioGenerator
  },
  {
    id: "username",
    title: "Username Generator",
    titleAr: "مولد اسماء المستخدمين",
    description: "Generate 10 brandable usernames",
    icon: User,
    color: "text-purple-400",
    component: UsernameGenerator
  },
  {
    id: "product",
    title: "Product Description Generator",
    titleAr: "مولد وصف المنتجات",
    description: "Generate high-converting sales descriptions",
    icon: ShoppingBag,
    color: "text-orange-400",
    component: ProductDescGenerator
  },
  {
    id: "dm",
    title: "DM Sales Script Generator",
    titleAr: "مولد رسائل المبيعات",
    description: "Generate ready-to-copy sales messages",
    icon: Mail,
    color: "text-cyan-400",
    component: DMScriptGenerator
  }
];

export default function Tools() {
  const [activeTool, setActiveTool] = useState("hashtag");
  const ActiveComponent = tools.find(t => t.id === activeTool)?.component || HashtagGenerator;
  const activeToolData = tools.find(t => t.id === activeTool);

  return (
    <div className="min-h-screen pt-20 pb-12 px-4">
      <div className="max-w-5xl mx-auto">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            Free SaaS Tools
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Marketing Tools Hub</h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-sm">
            Free tools to grow your social media. Fast, instant, no signup required.
          </p>
        </motion.div>

        <div className="grid grid-cols-3 md:grid-cols-6 gap-2 mb-6">
          {tools.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                onClick={() => setActiveTool(tool.id)}
                className={`
                  p-3 rounded-xl border transition-all text-center
                  ${activeTool === tool.id 
                    ? 'bg-primary/20 border-primary text-foreground' 
                    : 'bg-card/50 border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'}
                `}
                data-testid={`tab-${tool.id}`}
              >
                <Icon className={`w-5 h-5 mx-auto mb-1 ${activeTool === tool.id ? tool.color : ''}`} />
                <span className="text-[10px] md:text-xs block truncate">{tool.title.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>

        <motion.div
          key={activeTool}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          <Card className="bg-card border-border">
            <CardHeader className="pb-4">
              <CardTitle className="text-foreground flex items-center gap-2 text-lg">
                {activeToolData && <activeToolData.icon className={`w-5 h-5 ${activeToolData.color}`} />}
                {activeToolData?.title}
              </CardTitle>
              <CardDescription className="text-sm">{activeToolData?.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <ActiveComponent />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8 p-5 bg-gradient-to-r from-primary/10 to-purple-500/10 rounded-xl border border-primary/20 text-center"
        >
          <Rocket className="w-8 h-8 text-primary mx-auto mb-2" />
          <h3 className="text-lg font-bold text-foreground mb-1">More Features Coming Soon</h3>
          <p className="text-muted-foreground text-sm mb-4">
            AI-powered generation, advanced analytics, and more tools on the way!
          </p>
          <Button variant="outline" className="border-primary/50 text-primary" data-testid="button-coming-soon">
            <Sparkles className="w-4 h-4 mr-2" />
            More features coming soon
          </Button>
        </motion.div>

      </div>
    </div>
  );
}
