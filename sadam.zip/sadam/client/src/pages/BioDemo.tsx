import { useBioLinks } from "@/hooks/use-bio-links";
import { Globe, Instagram, MessageCircle, Briefcase, ExternalLink, ShoppingBag, Send, Youtube, Music } from "lucide-react";
import { SiTelegram, SiWhatsapp, SiInstagram, SiYoutube, SiTiktok } from "react-icons/si";
import { motion } from "framer-motion";

const iconMap: Record<string, any> = {
  Globe: Globe,
  Instagram: Instagram,
  MessageCircle: MessageCircle,
  Briefcase: Briefcase,
  ShoppingBag: ShoppingBag,
  Send: Send,
  Youtube: Youtube,
  Music: Music,
};

export default function BioDemo() {
  const { data: links, isLoading } = useBioLinks();

  const displayLinks = links?.length ? links : [
    { id: 1, title: "Visit Website", url: "https://example.com", icon: "Globe", order: 1 },
    { id: 2, title: "Instagram", url: "https://instagram.com", icon: "Instagram", order: 2 },
    { id: 3, title: "WhatsApp Support", url: "https://wa.me/1234567890", icon: "MessageCircle", order: 3 },
    { id: 4, title: "My Portfolio", url: "#", icon: "Briefcase", order: 4 },
  ];

  if (isLoading) return <div className="min-h-screen pt-20 flex items-center justify-center text-white">Loading...</div>;

  return (
    <div className="min-h-screen pt-20 pb-12 bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-800 font-sans">
      <div className="max-w-md mx-auto px-6">
        
        {/* Profile Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <div className="w-28 h-28 mx-auto bg-white rounded-full p-1 shadow-xl mb-4 ring-4 ring-white/30">
            <img 
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop" 
              alt="Profile" 
              className="w-full h-full rounded-full object-cover"
              data-testid="img-profile"
            />
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Sarah Creator</h1>
          <p className="text-white/80 mb-2">Digital Artist & Content Creator</p>
          <p className="text-white/60 text-sm max-w-xs mx-auto">
            Helping brands grow through creative content. Let's work together!
          </p>
        </motion.div>

        {/* Links */}
        <div className="space-y-4">
          {displayLinks.map((link, idx) => {
            const Icon = iconMap[link.icon] || ExternalLink;
            return (
              <motion.a
                key={link.id}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="
                  block w-full p-4 rounded-xl bg-white/10 hover:bg-white/20 
                  backdrop-blur-sm border border-white/20 text-white
                  flex items-center gap-4 transition-all duration-200
                  hover:scale-[1.02] hover:shadow-lg
                "
                data-testid={`link-${link.id}`}
              >
                <Icon className="w-6 h-6" />
                <span className="font-medium flex-1 text-center pr-6">{link.title}</span>
              </motion.a>
            );
          })}

          {/* Social Media Quick Links */}
          <div className="pt-6">
            <p className="text-center text-white/50 text-sm mb-4">Follow Me</p>
            <div className="flex justify-center gap-4">
              <motion.a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-gradient-to-br hover:from-pink-500 hover:to-orange-400 flex items-center justify-center text-white transition-all"
                data-testid="social-instagram"
              >
                <SiInstagram className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="https://t.me/username"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-[#0088cc] flex items-center justify-center text-white transition-all"
                data-testid="social-telegram"
              >
                <SiTelegram className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="https://wa.me/1234567890"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-[#25D366] flex items-center justify-center text-white transition-all"
                data-testid="social-whatsapp"
              >
                <SiWhatsapp className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-[#FF0000] flex items-center justify-center text-white transition-all"
                data-testid="social-youtube"
              >
                <SiYoutube className="w-5 h-5" />
              </motion.a>
              <motion.a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1 }}
                className="w-12 h-12 rounded-full bg-white/10 hover:bg-black flex items-center justify-center text-white transition-all"
                data-testid="social-tiktok"
              >
                <SiTiktok className="w-5 h-5" />
              </motion.a>
            </div>
          </div>

          {/* CTA Button */}
          <motion.a
            href="https://wa.me/1234567890?text=Hi! I'd like to work with you!"
            target="_blank"
            rel="noopener noreferrer"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="
              mt-8 block w-full p-4 rounded-xl bg-white text-purple-600
              font-bold text-center shadow-xl
              hover:shadow-2xl hover:scale-[1.02] transition-all duration-200
            "
            data-testid="link-cta-contact"
          >
            <span className="flex items-center justify-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Contact Me for Collaborations
            </span>
          </motion.a>
        </div>

        <div className="mt-12 text-center">
          <p className="text-white/40 text-sm font-mono">Powered by ProjectHub</p>
        </div>

      </div>
    </div>
  );
}
