import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ShoppingBag, ExternalLink, Sparkles, Brain, Youtube, Briefcase, TrendingUp, DollarSign, Laptop } from "lucide-react";
import { motion } from "framer-motion";

const products = [
  {
    id: 1,
    title: "AI Brainwave Program",
    titleAr: "برنامج الذكاء الاصطناعي",
    description: "Unlock your brain's full potential with AI-powered techniques",
    descriptionAr: "اطلق العنان لإمكانات عقلك الكاملة",
    url: "https://ingeniuswave.com/DSvsl/#aff=Saddam3300",
    icon: Brain,
    color: "from-purple-500 to-indigo-600",
    badge: "Hot"
  },
  {
    id: 2,
    title: "Online Income System",
    titleAr: "نظام الدخل عبر الإنترنت",
    description: "Complete system to generate income online from scratch",
    descriptionAr: "نظام كامل لتوليد دخل من الإنترنت",
    url: "https://www.digistore24.com/redir/423307/Saddam3300/",
    icon: DollarSign,
    color: "from-green-500 to-emerald-600",
    badge: "Popular"
  },
  {
    id: 3,
    title: "YouTube Automation Course",
    titleAr: "دورة أتمتة يوتيوب",
    description: "Learn how to build automated YouTube channels that earn",
    descriptionAr: "تعلم بناء قنوات يوتيوب تربح تلقائياً",
    url: "https://mattpar.com/tube-mastery-ds#aff=Saddam3300",
    icon: Youtube,
    color: "from-red-500 to-pink-600",
    badge: "Bestseller"
  },
  {
    id: 4,
    title: "Digital Business Course",
    titleAr: "دورة الأعمال الرقمية",
    description: "Build and scale your digital business from zero",
    descriptionAr: "ابني وطور عملك الرقمي من الصفر",
    url: "https://www.checkout-ds24.com/redir/610042/Saddam3300/",
    icon: Laptop,
    color: "from-blue-500 to-cyan-600",
    badge: "New"
  },
  {
    id: 5,
    title: "Affiliate Marketing System",
    titleAr: "نظام التسويق بالعمولة",
    description: "Master affiliate marketing and earn passive income",
    descriptionAr: "احترف التسويق بالعمولة واربح دخل سلبي",
    url: "https://www.digistore24.com/redir/489118/Saddam3300/",
    icon: TrendingUp,
    color: "from-orange-500 to-amber-600",
    badge: "Trending"
  },
  {
    id: 6,
    title: "High Ticket Marketing",
    titleAr: "تسويق المنتجات الفاخرة",
    description: "Learn to sell high-value products and services",
    descriptionAr: "تعلم بيع المنتجات عالية القيمة",
    url: "https://www.digistore24.com/redir/626995/Saddam3300/",
    icon: Briefcase,
    color: "from-violet-500 to-purple-600",
    badge: "Premium"
  },
  {
    id: 7,
    title: "Passive Income Course",
    titleAr: "دورة الدخل السلبي",
    description: "Create multiple streams of passive income",
    descriptionAr: "أنشئ مصادر متعددة للدخل السلبي",
    url: "https://www.checkout-ds24.com/redir/598501/Saddam3300/",
    icon: Sparkles,
    color: "from-teal-500 to-green-600",
    badge: "Limited"
  }
];

export default function Products() {
  return (
    <div className="min-h-screen pt-20 pb-12 px-4">
      <div className="max-w-6xl mx-auto">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <ShoppingBag className="w-4 h-4" />
            Digital Products | منتجات رقمية
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Saddam Hub Products</h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-sm">
            Premium digital courses and programs to start your online journey
          </p>
          <p className="text-primary text-sm mt-1">منتجات رقمية حصرية لبدء رحلتك في الربح من الإنترنت</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
          {products.map((product, idx) => {
            const Icon = product.icon;
            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + idx * 0.05 }}
              >
                <Card className="overflow-hidden bg-card border-border hover:border-primary/50 transition-all duration-300 h-full flex flex-col">
                  <CardHeader className={`p-0 relative bg-gradient-to-br ${product.color} h-32 flex items-center justify-center`}>
                    <Icon className="w-12 h-12 text-white/90" />
                    {product.badge && (
                      <div className="absolute top-3 right-3 bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-bold">
                        {product.badge}
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="p-4 flex-1">
                    <h3 className="text-base font-bold text-foreground mb-1">{product.title}</h3>
                    <p className="text-primary text-xs mb-2">{product.titleAr}</p>
                    <p className="text-muted-foreground text-xs">{product.description}</p>
                  </CardContent>
                  <CardFooter className="p-4 pt-0">
                    <Button 
                      className={`w-full bg-gradient-to-r ${product.color} text-white`}
                      data-testid={`button-buy-${product.id}`}
                      onClick={() => window.open(product.url, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Get Access | احصل عليه
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-center p-6 bg-gradient-to-r from-primary/10 to-purple-500/10 rounded-xl border border-primary/20"
        >
          <Sparkles className="w-10 h-10 text-primary mx-auto mb-3" />
          <h2 className="text-xl font-bold text-foreground mb-2">Start Your Journey Today</h2>
          <p className="text-muted-foreground text-sm">
            ابدأ رحلتك اليوم مع أفضل الدورات والبرامج الرقمية
          </p>
        </motion.div>

      </div>
    </div>
  );
}
