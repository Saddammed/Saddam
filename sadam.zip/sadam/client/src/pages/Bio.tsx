import { Link } from "wouter";
import { Gamepad2, Bot, ShoppingCart, ExternalLink, Zap } from "lucide-react";
import { SiTiktok, SiWhatsapp } from "react-icons/si";
import { motion } from "framer-motion";

const WHATSAPP_LINK = "https://wa.me/message/REDKIHRAVCUEB1";
const TIKTOK_LINK = "https://www.tiktok.com/@saddamhub";

const links = [
  {
    id: 1,
    title: "Game Topup",
    titleAr: "شحن الألعاب",
    description: "PUBG, Free Fire, eFootball, TikTok",
    url: "/topup",
    icon: Gamepad2,
    gradient: "from-emerald-500 to-green-600",
    external: false
  },
  {
    id: 2,
    title: "Telegram Bot",
    titleAr: "بوت تيليجرام",
    description: "Order & Get Links",
    url: "/bot",
    icon: Bot,
    gradient: "from-blue-500 to-cyan-500",
    external: false
  },
  {
    id: 3,
    title: "WhatsApp Orders",
    titleAr: "طلبات واتساب",
    description: "Direct support & orders",
    url: WHATSAPP_LINK,
    icon: SiWhatsapp,
    gradient: "from-[#25D366] to-[#128C7E]",
    external: true
  },
  {
    id: 4,
    title: "TikTok Channel",
    titleAr: "قناة تيك توك",
    description: "@saddamhub",
    url: TIKTOK_LINK,
    icon: SiTiktok,
    gradient: "from-pink-500 via-red-500 to-yellow-500",
    external: true
  },
  {
    id: 5,
    title: "Products",
    titleAr: "المنتجات",
    description: "Digital products & courses",
    url: "/products",
    icon: ShoppingCart,
    gradient: "from-purple-500 to-indigo-600",
    external: false
  }
];

export default function Bio() {
  return (
    <div className="min-h-screen pt-16 pb-12 bg-gradient-to-b from-background via-purple-900/10 to-background">
      <div className="max-w-md mx-auto px-4">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8"
        >
          <div className="w-24 h-24 mx-auto rounded-full p-1 bg-gradient-to-br from-primary via-purple-500 to-pink-500 mb-4 shadow-lg shadow-primary/30">
            <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
              <Zap className="w-10 h-10 text-primary" />
            </div>
          </div>
          
          <h1 className="text-2xl font-bold text-foreground mb-1">Saddam Hub</h1>
          <p className="text-primary text-sm font-medium mb-3">متجر رقمي</p>
          
          <div className="text-xs text-muted-foreground space-y-1 mb-4">
            <p>🎮 PUBG | Free Fire | eFootball</p>
            <p>💎 TikTok Coins</p>
            <p>💻 منتجات رقمية</p>
            <p>⚡ تسليم فوري</p>
          </div>
          
          <p className="text-foreground/90 text-sm">
            All our services in one place
          </p>
          <p className="text-muted-foreground text-xs">
            👇 اطلب الآن
          </p>
        </motion.div>

        <div className="space-y-3">
          {links.map((link, idx) => {
            const Icon = link.icon;
            
            const buttonContent = (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.08 }}
                className={`
                  w-full p-4 rounded-xl bg-gradient-to-r ${link.gradient}
                  flex items-center gap-4 transition-all duration-200
                  hover:shadow-xl hover:shadow-primary/20 
                  cursor-pointer relative overflow-visible hover-elevate
                `}
                data-testid={`link-bio-${link.id}`}
              >
                <div className="absolute inset-0 bg-white/5" />
                <div className="relative z-10 flex items-center gap-4 w-full">
                  <div className="w-11 h-11 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="font-bold text-white text-sm">{link.title}</div>
                    <div className="text-white/70 text-xs">{link.description}</div>
                  </div>
                  {link.external && (
                    <ExternalLink className="w-4 h-4 text-white/50" />
                  )}
                </div>
              </motion.div>
            );

            if (link.external) {
              return (
                <a 
                  key={link.id} 
                  href={link.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block"
                  data-testid={`a-bio-${link.id}`}
                >
                  {buttonContent}
                </a>
              );
            }

            return (
              <Link key={link.id} href={link.url} className="block" data-testid={`nav-bio-${link.id}`}>
                {buttonContent}
              </Link>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 grid grid-cols-3 gap-3 text-center"
        >
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xl font-bold text-primary">10K+</div>
            <div className="text-[10px] text-muted-foreground">Orders</div>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xl font-bold text-primary">5min</div>
            <div className="text-[10px] text-muted-foreground">Delivery</div>
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <div className="text-xl font-bold text-primary">24/7</div>
            <div className="text-[10px] text-muted-foreground">Support</div>
          </div>
        </motion.div>

        <div className="mt-8 text-center">
          <p className="text-muted-foreground/40 text-xs">Saddam Hub</p>
        </div>

      </div>
    </div>
  );
}
