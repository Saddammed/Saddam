import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Gamepad2, Shield, Zap, Clock } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { motion } from "framer-motion";

import pubgImage from "@assets/5994798825459092461_120_1768339571635.jpg";
import freeFireImage from "@assets/5994798825459092459_120_1768339571631.jpg";
import eFootballImage from "@assets/5994798825459092462_120_1768339571636.jpg";
import tiktokImage from "@assets/5994798825459092460_120_1768339571634.jpg";

const WHATSAPP_ORDER_LINK = "https://wa.me/message/REDKIHRAVCUEB1";

const games = [
  { value: "pubg", label: "PUBG Mobile", labelAr: "ببجي موبايل", icon: pubgImage },
  { value: "freefire", label: "Free Fire", labelAr: "فري فاير", icon: freeFireImage },
  { value: "efootball", label: "eFootball", labelAr: "إي فوتبول", icon: eFootballImage },
  { value: "tiktok", label: "TikTok Coins", labelAr: "عملات تيك توك", icon: tiktokImage }
];

export default function Topup() {
  const handleGameSelect = (game: typeof games[0]) => {
    window.open(WHATSAPP_ORDER_LINK, '_blank');
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-400 px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Gamepad2 className="w-4 h-4" />
            شحن الألعاب
          </div>
          <h1 className="text-4xl font-bold text-foreground mb-4">اشحن لعبتك</h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            شحن سريع وآمن لـ PUBG Mobile, Free Fire, eFootball, وعملات TikTok
          </p>
        </motion.div>

        {/* Trust Badges */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4 mb-10"
        >
          <div className="text-center p-4 bg-card rounded-xl border border-border">
            <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-sm font-bold text-foreground">فوري</div>
            <div className="text-xs text-muted-foreground">توصيل 5 دقائق</div>
          </div>
          <div className="text-center p-4 bg-card rounded-xl border border-border">
            <Shield className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
            <div className="text-sm font-bold text-foreground">آمن</div>
            <div className="text-xs text-muted-foreground">100% مضمون</div>
          </div>
          <div className="text-center p-4 bg-card rounded-xl border border-border">
            <Clock className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <div className="text-sm font-bold text-foreground">24/7</div>
            <div className="text-xs text-muted-foreground">دعم متواصل</div>
          </div>
        </motion.div>

        {/* Games Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <h2 className="text-xl font-bold text-foreground mb-6 text-center">اختر اللعبة</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {games.map((game, index) => (
              <motion.div
                key={game.value}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 * index }}
              >
                <Card 
                  className="bg-card border-border cursor-pointer hover-elevate transition-all duration-300 overflow-hidden group"
                  onClick={() => handleGameSelect(game)}
                  data-testid={`card-game-${game.value}`}
                >
                  <CardContent className="p-0">
                    <div className="aspect-square overflow-hidden">
                      <img 
                        src={game.icon} 
                        alt={game.label} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                      />
                    </div>
                    <div className="p-4 text-center">
                      <h3 className="font-bold text-foreground mb-1">{game.labelAr}</h3>
                      <p className="text-xs text-muted-foreground">{game.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* WhatsApp CTA */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-center"
        >
          <Card className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border-emerald-500/30">
            <CardContent className="p-6">
              <h3 className="font-bold text-foreground mb-3">اطلب الآن عبر واتساب</h3>
              <p className="text-muted-foreground text-sm mb-4">
                اختر لعبتك وسنتواصل معك فوراً لإتمام الطلب
              </p>
              <Button 
                size="lg"
                className="bg-[#25D366] hover:bg-[#128C7E] text-white h-14 px-8 rounded-xl text-lg"
                data-testid="button-whatsapp-order"
                onClick={() => window.open(WHATSAPP_ORDER_LINK, '_blank')}
              >
                <SiWhatsapp className="w-6 h-6 mr-2" />
                تواصل معنا
              </Button>
            </CardContent>
          </Card>
        </motion.div>

      </div>
    </div>
  );
}
