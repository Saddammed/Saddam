import { ProjectCard } from "@/components/ProjectCard";
import { ShoppingBag, Link2, Bot, Gamepad2, Sparkles, Rocket, DollarSign, Users } from "lucide-react";
import { motion } from "framer-motion";

const projects = [
  {
    title: "Product Landing Page",
    description: "Modern e-commerce landing page with hero section, trust badges, and PayPal/WhatsApp payment buttons. Perfect for selling physical or digital products.",
    href: "/demo/landing",
    icon: <ShoppingBag className="w-6 h-6" />,
    color: "blue-500",
    earning: "Sell products directly"
  },
  {
    title: "Bio Link Page",
    description: "Mobile-first social link hub for creators and influencers. Connect all your social profiles, products, and contact methods in one place.",
    href: "/demo/bio",
    icon: <Link2 className="w-6 h-6" />,
    color: "pink-500",
    earning: "Offer as a service"
  },
  {
    title: "Telegram Bot Dashboard",
    description: "Monitor your Telegram bot's activity with live logs. Automate customer support, send product links, and grow your audience 24/7.",
    href: "/demo/bot",
    icon: <Bot className="w-6 h-6" />,
    color: "sky-500",
    earning: "Sell bot services"
  },
  {
    title: "Game Top-up Store",
    description: "Digital currency purchase flow with form validation and WhatsApp ordering. Perfect for reselling game currency and digital items.",
    href: "/demo/topup",
    icon: <Gamepad2 className="w-6 h-6" />,
    color: "emerald-500",
    earning: "Earn per transaction"
  },
  {
    title: "SaaS Hashtag Generator",
    description: "AI-powered tool for generating viral hashtags. Ready to monetize with subscription plans or one-time payments.",
    href: "/demo/saas",
    icon: <Sparkles className="w-6 h-6" />,
    color: "violet-500",
    earning: "Subscription model"
  }
];

export default function Dashboard() {
  return (
    <div className="min-h-screen pt-24 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Hero */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6"
          >
            <Rocket className="w-4 h-4" />
            5 Ready-to-Deploy Templates
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold text-white mb-6"
          >
            Start Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">Online Business</span> Today
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8"
          >
            Each template is fully functional with payment buttons, contact links, and professional styling. 
            Clone, customize, and start earning immediately!
          </motion.p>
          
          {/* Stats */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center gap-8 mb-12"
          >
            <div className="text-center">
              <div className="text-3xl font-bold text-white">5</div>
              <div className="text-sm text-muted-foreground">Templates</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white flex items-center gap-1">
                <DollarSign className="w-6 h-6" />0
              </div>
              <div className="text-sm text-muted-foreground">Setup Cost</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white flex items-center gap-1">
                <Users className="w-6 h-6" />1K+
              </div>
              <div className="text-sm text-muted-foreground">Users</div>
            </div>
          </motion.div>
        </div>

        {/* Project Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, idx) => (
            <motion.div
              key={project.href}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + idx * 0.1 }}
            >
              <ProjectCard {...project} />
            </motion.div>
          ))}
        </div>

        {/* How It Works */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-20 text-center"
        >
          <h2 className="text-2xl font-bold text-white mb-8">How to Get Started</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-card rounded-xl p-6 border border-border">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold mx-auto mb-4">1</div>
              <h3 className="font-bold text-white mb-2">Choose a Template</h3>
              <p className="text-muted-foreground text-sm">Pick the template that fits your business idea</p>
            </div>
            <div className="bg-card rounded-xl p-6 border border-border">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold mx-auto mb-4">2</div>
              <h3 className="font-bold text-white mb-2">Customize Content</h3>
              <p className="text-muted-foreground text-sm">Add your products, links, and branding</p>
            </div>
            <div className="bg-card rounded-xl p-6 border border-border">
              <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold mx-auto mb-4">3</div>
              <h3 className="font-bold text-white mb-2">Start Earning</h3>
              <p className="text-muted-foreground text-sm">Share your link and receive payments</p>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
