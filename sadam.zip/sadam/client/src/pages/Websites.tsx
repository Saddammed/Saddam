import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/lib/i18n";
import { SiTelegram, SiWhatsapp } from "react-icons/si";
import { Globe, ShoppingCart, Smartphone, Palette, Zap, Shield, Code, Rocket } from "lucide-react";
import websiteMockup from "@assets/generated_images/professional_website_mockup.png";
import storeMockup from "@assets/generated_images/digital_store_mockup.png";

const TELEGRAM_LINK = "https://t.me/Saddammed";
const WHATSAPP_LINK = "https://wa.me/message/REDKIHRAVCUEB1";

export default function Websites() {
  const { language } = useLanguage();

  const services = [
    {
      icon: Globe,
      titleAr: "مواقع شخصية",
      titleEn: "Personal Websites",
      descAr: "موقع شخصي احترافي لعرض أعمالك ومهاراتك",
      descEn: "Professional personal website to showcase your work and skills"
    },
    {
      icon: ShoppingCart,
      titleAr: "متاجر إلكترونية",
      titleEn: "E-commerce Stores",
      descAr: "متجر إلكتروني متكامل لبيع منتجاتك أونلاين",
      descEn: "Complete online store to sell your products online"
    },
    {
      icon: Smartphone,
      titleAr: "مواقع متجاوبة",
      titleEn: "Responsive Design",
      descAr: "تصميم يعمل على جميع الأجهزة والشاشات",
      descEn: "Design that works on all devices and screens"
    },
    {
      icon: Palette,
      titleAr: "تصميم مخصص",
      titleEn: "Custom Design",
      descAr: "تصميم فريد يناسب هويتك التجارية",
      descEn: "Unique design that matches your brand identity"
    },
    {
      icon: Zap,
      titleAr: "سرعة عالية",
      titleEn: "High Speed",
      descAr: "مواقع سريعة التحميل لأفضل تجربة مستخدم",
      descEn: "Fast-loading websites for the best user experience"
    },
    {
      icon: Shield,
      titleAr: "أمان وحماية",
      titleEn: "Security & Protection",
      descAr: "حماية كاملة لموقعك وبيانات عملائك",
      descEn: "Complete protection for your site and customer data"
    }
  ];

  const features = [
    { ar: "دومين مجاني", en: "Free Domain" },
    { ar: "استضافة مجانية", en: "Free Hosting" },
    { ar: "شهادة SSL", en: "SSL Certificate" },
    { ar: "لوحة تحكم سهلة", en: "Easy Dashboard" },
    { ar: "دعم فني 24/7", en: "24/7 Support" },
    { ar: "تحسين محركات البحث", en: "SEO Optimization" }
  ];

  return (
    <div className="min-h-screen pt-20 pb-12 px-4" dir={language === "ar" ? "rtl" : "ltr"}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-4">
            <Code className="w-4 h-4" />
            <span className="text-sm font-medium">
              {language === "ar" ? "خدمة إنشاء المواقع" : "Website Creation Service"}
            </span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4" data-testid="text-websites-title">
            {language === "ar" ? "هل تحتاج موقعك الخاص؟" : "Need Your Own Website?"}
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            {language === "ar" 
              ? "نقوم بإنشاء مواقع شخصية وتجارية احترافية بأسعار مناسبة. تصميم عصري، سرعة عالية، ودعم فني متواصل."
              : "We create professional personal and commercial websites at suitable prices. Modern design, high speed, and continuous technical support."}
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg"
              className="bg-[#0088cc] text-white"
              onClick={() => window.open(TELEGRAM_LINK, '_blank')}
              data-testid="button-telegram-contact"
            >
              <SiTelegram className="w-5 h-5 me-2" />
              {language === "ar" ? "تواصل عبر تليجرام" : "Contact on Telegram"}
            </Button>
            <Button 
              size="lg"
              className="bg-[#25D366] text-white"
              onClick={() => window.open(WHATSAPP_LINK, '_blank')}
              data-testid="button-whatsapp-contact"
            >
              <SiWhatsapp className="w-5 h-5 me-2" />
              {language === "ar" ? "تواصل عبر واتساب" : "Contact on WhatsApp"}
            </Button>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="overflow-hidden bg-card/50 border-primary/20">
              <CardContent className="p-0">
                <img 
                  src={websiteMockup} 
                  alt="Professional Website" 
                  className="w-full h-64 object-cover"
                  data-testid="img-website-example"
                />
                <div className="p-4">
                  <h3 className="font-bold text-foreground text-lg mb-2">
                    {language === "ar" ? "مواقع شخصية احترافية" : "Professional Personal Websites"}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {language === "ar" 
                      ? "عرض أعمالك ومهاراتك بشكل احترافي"
                      : "Showcase your work and skills professionally"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card className="overflow-hidden bg-card/50 border-primary/20">
              <CardContent className="p-0">
                <img 
                  src={storeMockup} 
                  alt="E-commerce Store" 
                  className="w-full h-64 object-cover"
                  data-testid="img-store-example"
                />
                <div className="p-4">
                  <h3 className="font-bold text-foreground text-lg mb-2">
                    {language === "ar" ? "متاجر إلكترونية متكاملة" : "Complete E-commerce Stores"}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {language === "ar" 
                      ? "بيع منتجاتك أونلاين بسهولة"
                      : "Sell your products online easily"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-foreground text-center mb-8">
            {language === "ar" ? "خدماتنا" : "Our Services"}
          </h2>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <Card key={index} className="bg-card/50 border-primary/20 hover-elevate">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 mx-auto mb-4 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-bold text-foreground mb-2">
                      {language === "ar" ? service.titleAr : service.titleEn}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {language === "ar" ? service.descAr : service.descEn}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mb-16"
        >
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="p-8">
              <div className="flex items-center justify-center gap-2 mb-6">
                <Rocket className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-foreground">
                  {language === "ar" ? "ما تحصل عليه" : "What You Get"}
                </h2>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {features.map((feature, index) => (
                  <div 
                    key={index} 
                    className="flex items-center gap-2 bg-background/50 rounded-lg p-3"
                  >
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    <span className="text-foreground text-sm">
                      {language === "ar" ? feature.ar : feature.en}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center"
        >
          <Card className="bg-card/50 border-primary/20">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                {language === "ar" ? "جاهز للبدء؟" : "Ready to Start?"}
              </h2>
              <p className="text-muted-foreground mb-6">
                {language === "ar" 
                  ? "تواصل معنا الآن واحصل على موقعك الخاص بأسعار مناسبة"
                  : "Contact us now and get your own website at suitable prices"}
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                <Button 
                  size="lg"
                  className="bg-[#0088cc] text-white"
                  onClick={() => window.open(TELEGRAM_LINK, '_blank')}
                  data-testid="button-telegram-cta"
                >
                  <SiTelegram className="w-5 h-5 me-2" />
                  @Saddammed
                </Button>
                <Button 
                  size="lg"
                  className="bg-[#25D366] text-white"
                  onClick={() => window.open(WHATSAPP_LINK, '_blank')}
                  data-testid="button-whatsapp-cta"
                >
                  <SiWhatsapp className="w-5 h-5 me-2" />
                  WhatsApp
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
