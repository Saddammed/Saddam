import { useGenerateSaas } from "@/hooks/use-saas";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sparkles, Hash, Copy, Check, Zap, TrendingUp, Users, CreditCard } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { motion, AnimatePresence } from "framer-motion";

export default function SaasDemo() {
  const [keyword, setKeyword] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const generate = useGenerateSaas();

  const handleGenerate = () => {
    if (!keyword.trim()) return;
    generate.mutate(keyword, {
      onSuccess: (data) => {
        setResult(data.result);
      }
    });
  };

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 flex flex-col items-center bg-violet-950 font-sans">
      <div className="w-full max-w-3xl">
        
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-violet-500/20 text-violet-300 mb-6">
            <Hash className="w-8 h-8" />
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
            Hashtag Generator
          </h1>
          <p className="text-violet-200 text-lg max-w-lg mx-auto">
            Instantly generate viral hashtags for Instagram, TikTok, and Twitter. 
            Boost your reach and grow your audience!
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-3 gap-4 mb-10">
          <div className="text-center p-4 bg-white/5 rounded-xl border border-white/10">
            <Zap className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-white">Instant</div>
            <div className="text-xs text-violet-300">Generate in seconds</div>
          </div>
          <div className="text-center p-4 bg-white/5 rounded-xl border border-white/10">
            <TrendingUp className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-white">Trending</div>
            <div className="text-xs text-violet-300">Viral hashtags</div>
          </div>
          <div className="text-center p-4 bg-white/5 rounded-xl border border-white/10">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <div className="text-sm font-medium text-white">10K+</div>
            <div className="text-xs text-violet-300">Happy users</div>
          </div>
        </div>

        {/* Generator Input */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-2 shadow-2xl flex flex-col sm:flex-row gap-2">
          <Input 
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="Enter a keyword (e.g. travel, food, gym)"
            className="h-14 bg-transparent border-transparent text-white placeholder:text-violet-300/50 text-lg px-6 focus-visible:ring-0 focus-visible:ring-offset-0"
            onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
            data-testid="input-keyword"
          />
          <Button 
            onClick={handleGenerate}
            disabled={generate.isPending || !keyword.trim()}
            className="h-14 px-8 rounded-2xl bg-white text-violet-900 hover:bg-violet-50 font-bold text-lg transition-all"
            data-testid="button-generate"
          >
            {generate.isPending ? (
              <Sparkles className="w-5 h-5 animate-spin" />
            ) : (
              <>Generate <Sparkles className="w-4 h-4 ml-2" /></>
            )}
          </Button>
        </div>

        {/* Result */}
        <AnimatePresence>
          {(result || generate.isPending) && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-8"
            >
              <div className="bg-violet-900/50 border border-violet-800 rounded-3xl p-8 relative overflow-hidden group">
                <div className="absolute top-4 right-4">
                  <Button 
                    size="icon" 
                    variant="ghost" 
                    onClick={copyToClipboard}
                    className="text-violet-300 hover:bg-violet-800 hover:text-white"
                    data-testid="button-copy"
                  >
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                
                {generate.isPending ? (
                  <div className="space-y-3">
                    <div className="h-4 bg-violet-800 rounded w-3/4 animate-pulse" />
                    <div className="h-4 bg-violet-800 rounded w-1/2 animate-pulse" />
                  </div>
                ) : (
                  <>
                    <h3 className="text-sm font-bold text-violet-300 uppercase tracking-wider mb-3">Generated Hashtags</h3>
                    <p className="text-white text-lg leading-relaxed font-medium" data-testid="text-result">
                      {result}
                    </p>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Upgrade CTA */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-12 p-6 bg-gradient-to-r from-violet-600/20 to-purple-600/20 rounded-2xl border border-violet-500/30"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">
                Want Unlimited Generations?
              </h3>
              <p className="text-violet-200 text-sm">
                Upgrade to Pro for unlimited hashtags, bio generator, and caption writer!
              </p>
            </div>
            <div className="flex gap-3">
              <Button 
                className="bg-white text-violet-900 hover:bg-violet-50 font-bold px-6"
                data-testid="button-upgrade"
                onClick={() => window.open('https://paypal.me/yourname', '_blank')}
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Upgrade - $9.99/mo
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Contact */}
        <div className="mt-8 text-center">
          <p className="text-violet-300/60 text-sm mb-3">Questions about our tool?</p>
          <Button 
            variant="outline"
            className="border-violet-500/50 text-violet-200 hover:bg-violet-800"
            data-testid="button-contact"
            onClick={() => window.open('https://wa.me/1234567890?text=Hi! I have a question about the Hashtag Generator', '_blank')}
          >
            <SiWhatsapp className="w-4 h-4 mr-2" />
            Contact Us
          </Button>
        </div>

      </div>
    </div>
  );
}
