import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Calendar, LogOut, Settings, Shield, Gamepad2 } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/lib/i18n";

export default function Profile() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { t, language } = useLanguage();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: t("auth.login_required"),
        description: t("auth.redirecting"),
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isLoading, isAuthenticated, toast, t]);

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 pb-12 px-4 flex items-center justify-center">
        <div className="animate-pulse text-primary">{t("loading")}</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const initials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U';
  const fullName = [user.firstName, user.lastName].filter(Boolean).join(' ') || 'User';
  const memberSince = user.createdAt ? new Date(user.createdAt).toLocaleDateString(language === "ar" ? 'ar-EG' : 'en-US', { 
    year: 'numeric', 
    month: 'long' 
  }) : t("profile.not_set");

  return (
    <div className="min-h-screen pt-20 pb-12 px-4">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">
            {t("profile.title")}
          </h1>
          <p className="text-muted-foreground">{t("profile.subtitle")}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-border overflow-hidden">
            <div className="h-28 bg-gradient-to-br from-primary/20 via-primary/10 to-transparent" />
            
            <CardHeader className="relative -mt-14 pb-0">
              <div className="flex flex-col items-center">
                <Avatar className="w-24 h-24 border-4 border-card ring-2 ring-primary/30">
                  <AvatarImage src={user.profileImageUrl || undefined} alt={fullName} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <CardTitle className="mt-4 text-2xl text-foreground">{fullName}</CardTitle>
                <Badge className="mt-2">
                  <Shield className="w-3 h-3 me-1" />
                  {t("profile.member")}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="pt-6 space-y-4">
              <div className="grid gap-2">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{t("profile.name")}</p>
                    <p className="text-foreground font-medium">{fullName}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{t("profile.email")}</p>
                    <p className="text-foreground font-medium">{user.email || t("profile.not_set")}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{t("profile.joined")}</p>
                    <p className="text-foreground font-medium">{memberSince}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                    <Gamepad2 className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{t("profile.status")}</p>
                    <p className="text-emerald-500 font-medium">{t("profile.active")}</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-border space-y-2">
                <Button
                  variant="outline"
                  className="w-full"
                  data-testid="button-settings"
                  disabled
                >
                  <Settings className="w-4 h-4 me-2" />
                  {t("profile.settings")}
                </Button>
                
                <Button
                  variant="destructive"
                  className="w-full"
                  onClick={() => window.location.href = "/api/logout"}
                  data-testid="button-logout-profile"
                >
                  <LogOut className="w-4 h-4 me-2" />
                  {t("profile.logout")}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
