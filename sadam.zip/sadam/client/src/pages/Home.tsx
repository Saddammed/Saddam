import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Link2, Gamepad2, Bot, Wrench, Zap, Globe } from "lucide-react";
import { SiTiktok, SiWhatsapp, SiTelegram } from "react-icons/si";
import { motion } from "framer-motion";
import { useLanguage } from "@/lib/i18n";
import websiteMockup from "@assets/generated_images/professional_website_mockup.png";
import storeMockup from "@assets/generated_images/digital_store_mockup.png";

const WHATSAPP_LINK = "https://wa.me/message/REDKIHRAVCUEB1";
const TELEGRAM_LINK = "https://t.me/Saddammed";
const TIKTOK_LINK = "https://www.tiktok.com/@saddamhub";

export default function Home() {
  const { t, language } = useLanguage();

  const sections = [
    { href: "/products", labelAr: "المنتجات", labelEn: "Digital Products Store", icon: ShoppingBag, color: "from-pink-500 to-rose-500", descAr: "دورات ومنتجات رقمية احترافية", descEn: "Premium digital courses & products" },
    { href: "/bio", labelAr: "الروابط", labelEn: "Bio Links", icon: Link2, color: "from-purple-500 to-violet-500", descAr: "جميع روابطنا في مكان واحد", descEn: "All our links in one place" },
    { href: "/topup", labelAr: "شحن الألعاب", labelEn: "Digital Game Top-Ups", icon: Gamepad2, color: "from-emerald-500 to-green-500", descAr: "PUBG، Free Fire، eFootball، TikTok Coins", descEn: "PUBG Top Up, Free Fire Recharge, eFootball Coins, TikTok Coins" },
    { href: "/bot", labelAr: "بوت تليجرام", labelEn: "Telegram Bot", icon: Bot, color: "from-blue-500 to-cyan-500", descAr: "بوت تسويق آلي", descEn: "Automated marketing bot" },
    { href: "/tools", labelAr: "أدوات مجانية", labelEn: "SaaS Tools", icon: Wrench, color: "from-orange-500 to-amber-500", descAr: "أدوات تسويق مجانية", descEn: "Free marketing tools" },
  ];

  return (
    <div className="min-h-screen pt-20 pb-12 px-4">
      <div className="max-w-5xl mx-auto">
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6 neon-border">
            <Zap className="w-4 h-4" />
            {t("home.gaming_hub")}
          </div>
          <h1 className="text-4xl md:text-6xl text-foreground mb-3 brand-heading">
            {language === "ar" ? "متجر" : "Saddam"} <span className="neon-text text-white">{language === "ar" ? "صدام" : "Store"}</span>
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground tracking-wide mb-6">
            Game Top-Up &bull; Digital Products &bull; SaaS Tools &bull; Website Creation &bull; Marketing Bot
          </p>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
            {t("home.subtitle")}
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Button 
              size="lg"
              className="bg-[#25D366] text-white rounded-full"
              data-testid="button-whatsapp-hero"
              onClick={() => window.open(WHATSAPP_LINK, '_blank')}
            >
              <SiWhatsapp className="w-5 h-5 me-2" />
              {t("home.whatsapp_order")}
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="rounded-full"
              data-testid="button-tiktok-hero"
              onClick={() => window.open(TIKTOK_LINK, '_blank')}
            >
              <SiTiktok className="w-5 h-5 me-2" />
              {t("home.tiktok_follow")}
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section, idx) => {
            const Icon = section.icon;
            return (
              <motion.div
                key={section.href}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + idx * 0.1 }}
              >
                <Link href={section.href} data-testid={`link-section-${section.href.replace('/', '')}`}>
                  <div className="group relative overflow-hidden rounded-2xl p-6 h-full bg-card border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer">
                    <div className={`absolute top-0 ${language === "ar" ? "left-0" : "right-0"} w-32 h-32 bg-gradient-to-br ${section.color} rounded-full blur-3xl opacity-20 group-hover:opacity-40 transition-opacity`} />
                    
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${section.color} flex items-center justify-center mb-4`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    
                    <h3 className="text-xl font-bold text-foreground mb-2">{language === "ar" ? section.labelAr : section.labelEn}</h3>
                    <p className="text-muted-foreground text-sm">{language === "ar" ? section.descAr : section.descEn}</p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mt-16"
        >
          <div className="relative overflow-hidden rounded-2xl p-8 bg-card border border-border">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-full blur-3xl opacity-20" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full blur-3xl opacity-20" />
            
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-foreground brand-heading">
                  {language === "ar" ? "هل تحتاج موقعك الخاص؟" : "Need Your Own Website?"}
                </h2>
              </div>
              
              <p className="text-muted-foreground mb-6 max-w-2xl">
                {language === "ar" 
                  ? "نقوم بإنشاء مواقع شخصية وتجارية لك بأسعار مناسبة. تواصل معنا عبر تليجرام أو واتساب لإنشاء موقعك الاحترافي."
                  : "We build personal and commercial websites for you at suitable prices. Contact us on Telegram or WhatsApp to create your professional website."}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="rounded-xl overflow-hidden border border-border">
                  <img 
                    src={websiteMockup} 
                    alt={language === "ar" ? "تصميم موقع احترافي" : "Professional website design"}
                    className="w-full h-40 object-cover"
                    data-testid="img-website-mockup"
                  />
                  <div className="p-3 bg-muted/50">
                    <p className="text-sm text-foreground font-medium">
                      {language === "ar" ? "مواقع احترافية" : "Professional Websites"}
                    </p>
                  </div>
                </div>
                <div className="rounded-xl overflow-hidden border border-border">
                  <img 
                    src={storeMockup} 
                    alt={language === "ar" ? "متجر إلكتروني" : "E-commerce store design"}
                    className="w-full h-40 object-cover"
                    data-testid="img-store-mockup"
                  />
                  <div className="p-3 bg-muted/50">
                    <p className="text-sm text-foreground font-medium">
                      {language === "ar" ? "متاجر إلكترونية" : "E-commerce Stores"}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <Button 
                  className="bg-[#0088cc] text-white"
                  onClick={() => window.open(TELEGRAM_LINK, '_blank')}
                  data-testid="button-telegram-website"
                >
                  <SiTelegram className="w-4 h-4 me-2" />
                  {language === "ar" ? "تواصل عبر تليجرام" : "Contact on Telegram"}
                </Button>
                <Button 
                  className="bg-[#25D366] text-white"
                  onClick={() => window.open(WHATSAPP_LINK, '_blank')}
                  data-testid="button-whatsapp-website"
                >
                  <SiWhatsapp className="w-4 h-4 me-2" />
                  {language === "ar" ? "تواصل عبر واتساب" : "Contact on WhatsApp"}
                </Button>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
        >
          <div>
            <div className="text-3xl font-bold text-primary mb-1">24/7</div>
            <div className="text-sm text-muted-foreground">{language === "ar" ? "دعم مستمر" : "Gaming Store Support"}</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-1">5{language === "ar" ? "د" : "min"}</div>
            <div className="text-sm text-muted-foreground">{language === "ar" ? "شحن فوري" : "Online Game Recharge"}</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-1">10K+</div>
            <div className="text-sm text-muted-foreground">{language === "ar" ? "طلب ناجح" : "Top-Up Orders"}</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-primary mb-1">100%</div>
            <div className="text-sm text-muted-foreground">{language === "ar" ? "آمن ومضمون" : "Secure Orders"}</div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}
