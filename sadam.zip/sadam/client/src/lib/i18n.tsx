import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  dir: "rtl" | "ltr";
}

const translations: Record<Language, Record<string, string>> = {
  ar: {
    // Navigation
    "nav.products": "المنتجات",
    "nav.bio": "الروابط",
    "nav.topup": "الشحن",
    "nav.bot": "البوت",
    "nav.tools": "الأدوات",
    "nav.websites": "المواقع",
    "nav.login": "دخول",
    "nav.profile": "حسابي",
    
    // Home
    "home.title": "متجر صدام",
    "home.subtitle": "متجر منتجات رقمية وشحن الألعاب - PUBG Top Up، Free Fire، TikTok Coins وأكثر",
    "home.gaming_hub": "Digital Gaming Store",
    "home.whatsapp_order": "اطلب عبر واتساب",
    "home.tiktok_follow": "تابعنا على تيك توك",
    
    // Products
    "products.title": "المنتجات",
    "products.subtitle": "دورات ومنتجات رقمية احترافية",
    "products.buy": "شراء الآن",
    
    // Bio
    "bio.title": "روابطنا",
    "bio.subtitle": "تابعنا على جميع المنصات",
    
    // Topup
    "topup.title": "شحن الألعاب",
    "topup.subtitle": "اشحن رصيدك في ألعابك المفضلة",
    "topup.player_id": "معرف اللاعب",
    "topup.select_game": "اختر اللعبة",
    "topup.select_amount": "اختر المبلغ",
    "topup.order_whatsapp": "اطلب عبر واتساب",
    
    // Bot
    "bot.title": "بوت تليجرام",
    "bot.subtitle": "بوت آلي للتسويق والخدمات",
    "bot.start": "ابدأ المحادثة",
    "bot.copy": "نسخ رابط البوت",
    "bot.copied": "تم النسخ!",
    
    // Tools
    "tools.title": "أدوات مجانية",
    "tools.subtitle": "أدوات تسويق احترافية مجانية",
    "tools.generate": "توليد",
    "tools.copy": "نسخ",
    "tools.copied": "تم النسخ!",
    
    // Profile
    "profile.title": "حسابي الشخصي",
    "profile.subtitle": "إدارة معلومات حسابك",
    "profile.name": "الاسم",
    "profile.email": "البريد الإلكتروني",
    "profile.joined": "تاريخ الانضمام",
    "profile.status": "الحالة",
    "profile.active": "نشط",
    "profile.member": "عضو مميز",
    "profile.settings": "إعدادات الحساب",
    "profile.logout": "تسجيل الخروج",
    "profile.not_set": "غير محدد",
    
    // Auth
    "auth.login_required": "يرجى تسجيل الدخول",
    "auth.redirecting": "جاري التوجيه لصفحة الدخول...",
    
    // Common
    "loading": "جاري التحميل...",
  },
  en: {
    // Navigation
    "nav.products": "Products",
    "nav.bio": "Bio",
    "nav.topup": "Topup",
    "nav.bot": "Bot",
    "nav.tools": "Tools",
    "nav.websites": "Websites",
    "nav.login": "Login",
    "nav.profile": "Profile",
    
    // Home
    "home.title": "Saddam Store",
    "home.subtitle": "Your Digital Products Store for PUBG Top Up, Free Fire Recharge, TikTok Coins Top Up & eFootball Coins",
    "home.gaming_hub": "Digital Gaming Store",
    "home.whatsapp_order": "Order on WhatsApp",
    "home.tiktok_follow": "Follow on TikTok",
    
    // Products
    "products.title": "Products",
    "products.subtitle": "Professional digital courses and products",
    "products.buy": "Buy Now",
    
    // Bio
    "bio.title": "Our Links",
    "bio.subtitle": "Follow us on all platforms",
    
    // Topup
    "topup.title": "Game Topup",
    "topup.subtitle": "Top up your favorite games",
    "topup.player_id": "Player ID",
    "topup.select_game": "Select Game",
    "topup.select_amount": "Select Amount",
    "topup.order_whatsapp": "Order via WhatsApp",
    
    // Bot
    "bot.title": "Telegram Bot",
    "bot.subtitle": "Automated marketing bot",
    "bot.start": "Start Chat",
    "bot.copy": "Copy Bot Link",
    "bot.copied": "Copied!",
    
    // Tools
    "tools.title": "Free Tools",
    "tools.subtitle": "Professional marketing tools for free",
    "tools.generate": "Generate",
    "tools.copy": "Copy",
    "tools.copied": "Copied!",
    
    // Profile
    "profile.title": "My Profile",
    "profile.subtitle": "Manage your account information",
    "profile.name": "Name",
    "profile.email": "Email",
    "profile.joined": "Joined",
    "profile.status": "Status",
    "profile.active": "Active",
    "profile.member": "Premium Member",
    "profile.settings": "Account Settings",
    "profile.logout": "Logout",
    "profile.not_set": "Not set",
    
    // Auth
    "auth.login_required": "Please login",
    "auth.redirecting": "Redirecting to login...",
    
    // Common
    "loading": "Loading...",
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("language") as Language) || "ar";
    }
    return "ar";
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  };

  useEffect(() => {
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const dir = language === "ar" ? "rtl" : "ltr";

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
