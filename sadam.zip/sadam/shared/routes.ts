import { z } from 'zod';
import { 
  insertProductSchema, products,
  insertBioLinkSchema, bioLinks,
  insertTopupRequestSchema, topupRequests,
  insertSaasGenerationSchema, saasGenerations,
  botLogs
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  // Project 1: Landing Page
  products: {
    list: {
      method: 'GET' as const,
      path: '/api/products',
      responses: {
        200: z.array(z.custom<typeof products.$inferSelect>()),
      },
    },
  },

  // Project 2: Bio Link
  bioLinks: {
    list: {
      method: 'GET' as const,
      path: '/api/bio-links',
      responses: {
        200: z.array(z.custom<typeof bioLinks.$inferSelect>()),
      },
    },
  },

  // Project 3: Telegram Bot
  bot: {
    logs: {
      method: 'GET' as const,
      path: '/api/bot/logs',
      responses: {
        200: z.array(z.custom<typeof botLogs.$inferSelect>()),
      },
    },
    status: {
      method: 'GET' as const,
      path: '/api/bot/status',
      responses: {
        200: z.object({ status: z.enum(['running', 'stopped']), uptime: z.number() }),
      },
    },
  },

  // Project 4: Game Top-up
  topups: {
    create: {
      method: 'POST' as const,
      path: '/api/topups',
      input: insertTopupRequestSchema,
      responses: {
        201: z.custom<typeof topupRequests.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/topups',
      responses: {
        200: z.array(z.custom<typeof topupRequests.$inferSelect>()),
      },
    },
  },

  // Project 5: SaaS Tool
  saas: {
    generate: {
      method: 'POST' as const,
      path: '/api/saas/generate',
      input: z.object({ keyword: z.string().min(1) }),
      responses: {
        201: z.custom<typeof saasGenerations.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
